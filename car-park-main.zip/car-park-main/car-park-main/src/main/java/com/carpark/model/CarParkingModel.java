package com.carpark.model;

public class CarParkingModel 
{
	private final String carNumber;
	private final int duration;
	
	public CarParkingModel(String carNumber, int duration) 
	{
		this.carNumber = carNumber;
		this.duration = duration;
	}

	public String getCarNumber() {
		return carNumber;
	}

	public int getDuration() {
		return duration;
	}
}
