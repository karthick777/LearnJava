package com.carpark;

public class InvalidDurationException extends RuntimeException
{
	
}
