package com.carpark.service;

import java.time.LocalDateTime;

import com.carpark.InvalidDurationException;
import com.carpark.model.CarParkingModel;
import com.carpark.repository.CarParkingSlot;

public class CarParkingService 

{
	public CarParkingSlot allotParking(CarParkingModel carParkingModel) 
	{
		if(carParkingModel.getDuration() < 1 || carParkingModel.getDuration() > 4)
		{
			throw new InvalidDurationException();
		}
		
		CarParkingSlot carParkingSlot = new CarParkingSlot(carParkingModel.getCarNumber(), carParkingModel.getDuration(), LocalDateTime.now());
		return carParkingSlot;
	}
}
