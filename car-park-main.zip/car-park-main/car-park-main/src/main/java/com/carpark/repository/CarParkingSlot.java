package com.carpark.repository;

import java.time.LocalDateTime;
import java.util.UUID;

public final class CarParkingSlot {
	
	private final String carNumber;
	private final int duration;
	private final String parkingId;
	private final LocalDateTime startTime;
	

	public CarParkingSlot(String carNumber, int duration, LocalDateTime startTime) {
		this.carNumber = carNumber;
		this.duration = duration;
		this.parkingId = UUID.randomUUID().toString();
		this.startTime = startTime;
	}

	public String getCarNumber() {
		return carNumber;
	}

	public int getDuration() {
		return duration;
	}

	public String getParkingId() {
		return parkingId;
	}

	public LocalDateTime getStartTime() {
		return startTime;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((carNumber == null) ? 0 : carNumber.hashCode());
		result = prime * result + duration;
		result = prime * result + ((startTime == null) ? 0 : startTime.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CarParkingSlot other = (CarParkingSlot) obj;
		if (carNumber == null) {
			if (other.carNumber != null)
				return false;
		} else if (!carNumber.equals(other.carNumber))
			return false;
		if (duration != other.duration)
			return false;
		if (startTime == null) {
			if (other.startTime != null)
				return false;
		} else if (!startTime.equals(other.startTime))
			return false;
		return true;
	}

	
}
