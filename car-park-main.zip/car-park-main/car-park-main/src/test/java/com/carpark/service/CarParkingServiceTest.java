package com.carpark.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.carpark.InvalidDurationException;
import com.carpark.model.CarParkingModel;
import com.carpark.repository.CarParkingSlot;

public class CarParkingServiceTest {
	
	CarParkingService carParkingService;
	
	@BeforeEach
	public void setup()
	{
	 carParkingService = new CarParkingService();
	}
	
	@Test
	public void carParking_durationLessThanOne_exception()
	{
		String carNumber = "TN58-0001";
		int duration = 0;
		
		CarParkingModel carParkingModel = new CarParkingModel(carNumber, duration);
		
		assertThrows(InvalidDurationException.class, ()->
		{
			carParkingService.allotParking(carParkingModel);
		});
	}
	
	@Test
	public void carParking_durationGreaterThanFour_exception()
	{
		String carNumber = "TN58-0001";
		int duration = 5;
		
		CarParkingModel carParkingModel = new CarParkingModel(carNumber, duration);
		
		assertThrows(InvalidDurationException.class, ()->
		{
			carParkingService.allotParking(carParkingModel);
		});
	}
	
	@Test
	public void carParking_bookingSuccesful()
	{
		String carNumber = "TN59-0002";
		int duration = 2;
		
		CarParkingModel carParkingModel = new CarParkingModel(carNumber, duration);
		
		CarParkingSlot parkingSlot = carParkingService.allotParking(carParkingModel);
		
		assertEquals(carNumber, parkingSlot.getCarNumber());
		
	}
}


