package com.carpark.repository;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.time.LocalDateTime;

import org.junit.jupiter.api.Test;

public class CarParkingSlotTest {
	
	@Test
	public void equalityTest()
	{
		String carNumber = "TN58-0007";
		int duration = 2;
		LocalDateTime startTime = LocalDateTime.now();
		
		CarParkingSlot carParkingSlotA = new CarParkingSlot(carNumber, duration,startTime);
		CarParkingSlot carParkingSlotB = new CarParkingSlot(carNumber, duration,startTime);
		
		assertEquals(carParkingSlotA, carParkingSlotB);
		
	}

}
